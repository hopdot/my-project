// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title HCOINX (HCXX)
 * @dev ERC20 Token owned by Howard Mosely (gmo.hc93@gmail.com)
 */
contract HCOINX is ERC20, Ownable {
    constructor(uint256 initialSupply) ERC20("HCOINX", "HCXX") {
        _mint(msg.sender, initialSupply * 10 ** decimals());
    }

    function mint(address to, uint256 amount) public onlyOwner {
        _mint(to, amount * 10 ** decimals());
    }
}
