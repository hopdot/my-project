# HCoinX Complete Slot Machine Package

Includes:
- On-chain HCX Slot Machine contract
- Wix-compatible frontend
- Facebook Stars placeholder

Steps:
1. Deploy HCoinX token
2. Deploy slot machine with token address
3. Update frontend CONTRACT constant

Test on Sepolia before Mainnet.
