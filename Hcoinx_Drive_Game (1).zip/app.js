
function applyCustomization() {
    const carModel = document.getElementById('carModel').value;
    const carColor = document.getElementById('carColor').value;
    const carUpgrade = document.getElementById('carUpgrade').value;
    alert(`Customization Applied:\nModel: ${carModel}\nColor: ${carColor}\nUpgrade: ${carUpgrade}`);
    document.getElementById('carPreview').style.backgroundColor = carColor;
}

function initializeGame() {
    console.log("Initializing Hcoinx Drive...");
    document.getElementById('carPreview').style.backgroundColor = document.getElementById('carColor').value;
}

window.onload = function () {
    initializeGame();
    document.getElementById('applyCustomizationBtn').addEventListener('click', applyCustomization);
};
